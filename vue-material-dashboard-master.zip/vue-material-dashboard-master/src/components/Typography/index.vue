<template lang="pug">
.content
  .container-fluid
    .row
      .col-md-12
        .card
          .card-header(data-background-color='purple')
            h4.title Material Dashboard Heading
            p.category Created using Roboto Font Family
          .card-content
            #typography
              .title
                h2 Typography
              .row
                .tim-typo
                  h1
                    span.tim-note Header 1
                    | The Life of Material Dashboard
                .tim-typo
                  h2
                    span.tim-note Header 2
                    | The life of Material Dashboard
                .tim-typo
                  h3
                    span.tim-note Header 3
                    | The life of Material Dashboard
                .tim-typo
                  h4
                    span.tim-note Header 4
                    | The life of Material Dashboard
                .tim-typo
                  h5
                    span.tim-note Header 5
                    | The life of Material Dashboard
                .tim-typo
                  h6
                    span.tim-note Header 6
                    | The life of Material Dashboard
                .tim-typo
                  p
                    span.tim-note Paragraph
                    | I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at.
                .tim-typo
                  span.tim-note Quote
                  md-blockquote(author='Kanye West, Musician', content='I will be the leader of a company that ends up being worth billions of dollars, because I got the answers. I understand culture. I am the nucleus. I think that’s a responsibility that I have, to push possibilities, to show people, this is the level that things could be at.')
                .tim-typo
                  span.tim-note Muted Text
                  p.text-muted
                    | I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...
                .tim-typo
                  span.tim-note Primary Text
                  p.text-primary
                    | I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...
                .tim-typo
                  span.tim-note Info Text
                  p.text-info
                    | I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...
                .tim-typo
                  span.tim-note Success Text
                  p.text-success
                    | I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...
                .tim-typo
                  span.tim-note Warning Text
                  p.text-warning
                    | I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...
                .tim-typo
                  span.tim-note Danger Text
                  p.text-danger
                    | I will be the leader of a company that ends up being worth billions of dollars, because I got the answers...
                .tim-typo
                  h2
                    span.tim-note Small Tag
                    | Header with small subtitle 
                    br
                    small Use "small" tag for the headers
</template>

<script>
export default {

}
</script>
<style lang="sass">

</style>

