
export const EVENT_ON_TAB_CLICK = 'onTabClick'
